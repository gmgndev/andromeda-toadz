# Andromeda Cryptoadz
Cryptoadz NFT collection for the METIS network

### Stack
* Solidity 0.6.x ([OpenZeppelin](https://docs.openzeppelin.com/contracts/4.x/))
* Hardhat
