import "./App.css";
import { Layout } from "./app.styles";
import Minter from "./Minter";

function App() {
  return (
    <Layout>
      <Minter />
    </Layout>
  );
}

export default App;
