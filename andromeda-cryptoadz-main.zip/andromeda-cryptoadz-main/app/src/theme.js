export const theme = {
  bg: "#002032",
  titleText: "#00DACB",
  text: "white",
  ctaBg: "#7367CD",
};
