import styled from "styled-components";

export const Layout = styled.div`
  background: ${(props) => props.theme.bg};
  min-height: 100vh;
`;
